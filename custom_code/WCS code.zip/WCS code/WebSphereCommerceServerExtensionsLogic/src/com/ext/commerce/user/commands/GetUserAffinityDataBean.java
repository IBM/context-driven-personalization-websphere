package com.ext.commerce.user.commands;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.CreateException;
import javax.naming.NamingException;

import org.apache.commons.json.JSONArray;
import org.apache.commons.json.JSONException;
import org.apache.commons.json.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.apache.wink.common.http.HttpStatus;

import com.ibm.commerce.base.objects.ServerJDBCHelperAccessBean;
import com.ibm.commerce.beans.SmartDataBean;
import com.ibm.commerce.beans.SmartDataBeanImpl;
import com.ibm.commerce.foundation.common.util.logging.LoggingHelper;
import com.ibm.commerce.foundation.internal.client.contextservice.RemoteCallException;
import com.ibm.commerce.foundation.internal.server.services.search.config.solr.SolrSearchConfigurationRegistry;
import com.ibm.commerce.foundation.internal.server.services.search.util.RemoteRestCallHelper;


/**
 * @author IBM
 * This data bean fetches the user attribute affinity and attribute preference and returned to the calling component. 	 
 * 
 */

public class GetUserAffinityDataBean extends SmartDataBeanImpl implements
		SmartDataBean {
	private static final String CLASSNAME = "com.ext.commerce.user.commands.GetUserAffinityDataBean";
	private static final Logger LOGGER = LoggingHelper.getLogger(CLASSNAME);
	
	private String categoryId=null;
	private String searchTerm = null;
	private String attrPrefCount = null;
	private Map<String, String> prefAttrMap = null;
	private String isAttinity = null;
	
	



	public String getIsAttinity() {
		return isAttinity;
	}



	public void setIsAttinity(String isAttinity) {
		this.isAttinity = isAttinity;
	}



	public Map<String, String> getPrefAttrMap() {
		return prefAttrMap;
	}



	public void setPrefAttrMap(Map<String, String> prefAttrMap) {
		this.prefAttrMap = prefAttrMap;
	}



	public String getAttrPrefCount() {
		return attrPrefCount;
	}



	public void setAttrPrefCount(String attrPrefCount) {
		this.attrPrefCount = attrPrefCount;
	}



	public String getSearchTerm() {
		return searchTerm;
	}



	public void setSearchTerm(String searchTerm) {
		this.searchTerm = searchTerm;
	}



	public String getCategoryId() {
		return categoryId;
	}



	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}


	private ArrayList<String> promotionCode=null;

	public ArrayList<String> getPromotionCode() {
		return promotionCode;
	}





	public void setPromotionCode(ArrayList<String> promoCode) {
		this.promotionCode = promoCode;
	}

	/**
	 * @param userId	 
	 * @return List
	 * @throws Exception
	 * The main poulate method which makes call to 	 getUserPrefferedCategory method to fetch the user affinity category.
	 * Also makes call to getPrefferedCategoryBySearchTerm method to get the category list for the supplied search term.
	 */
	
	@Override
	public void populate() throws Exception {
		// TODO Auto-generated method stub
		super.populate();		
		//String strExpression = "price_USD" + ":" + "({* 100} 100)";
			Long userId = getCommandContext().getUserId();
			String userIdStr = null;
			if(userId != null)
			userIdStr = String.valueOf(userId);
			
			if(StringUtils.isEmpty(getCategoryId())) {			
			List<String> userCat = getUserPrefferedCategory(userIdStr);
			List<String> userPrefCategory = getPrefferedCategoryBySearchTerm(searchTerm, "1","12", "IBM_findProductsBySearchTerm");
			userCat.retainAll(userPrefCategory);
			if(userCat != null && userCat.size() >0)
			setCategoryId(userCat.get(0));
			}
			
			else if ("true".equalsIgnoreCase(getIsAttinity())) {				
				getUserAffinityAttribute(userIdStr, getCategoryId(), "0");
				getUserBrandAffinityAttribute(userIdStr,getCategoryId());
			}
			
			else {
				getUserPrefferedAttribute(userIdStr, getCategoryId(), "1");
			}
			
			System.err.println("My Databean executed Successfully\n");
					
	}
	
	/**
	 * @param userId	 
	 * @return List
	 * This method will accept userId and return list of preffered attribute affinity for the user.	 
	 */

	public List<String> getUserPrefferedCategory(String userId){
		String METHODNAME = "getUserPrefferedCategory";
		if (LoggingHelper.isEntryExitTraceEnabled(LOGGER))
		LOGGER.entering(CLASSNAME, METHODNAME);		
		
		String sqlQuery = "SELECT CATID FROM USER_CAT_AFFINITY WHERE USERS_ID=? ORDER BY CATID DESC";
		Serializable sqlParam[] = { userId };		
		
		Vector result = null;
		List<String> userCat = null;		
		ServerJDBCHelperAccessBean helperAB = new ServerJDBCHelperAccessBean();
		try {
			userCat = new ArrayList<String>();
			result = helperAB.executeParameterizedQuery(sqlQuery, sqlParam);
			 
		} catch (RemoteException | NamingException | SQLException
				| CreateException e) {			
			LOGGER.logp(Level.SEVERE, CLASSNAME, METHODNAME,  "Exception Occur while fetching User Affinity Details", e.getMessage());			
		}		
		String temp = null;
		if(result != null) {
		for(Object obj : result ) {
			Vector row = (Vector) obj;
             temp = row.get(0).toString();
			userCat.add(temp);			
        }
		}
		
		return userCat;
	
	}
	
	/**
	 * @param userId	 
	 * @return List
	 * This method will accept userId and return list of preferred attribute affinity for the user.	 
	 */

	public void getUserPrefferedAttribute(String userId, String categoryId, String isattrPref){
		
		String METHODNAME = "getUserPrefferedAttribute";
		if (LoggingHelper.isEntryExitTraceEnabled(LOGGER))
		LOGGER.entering(CLASSNAME, METHODNAME);		
		
		String sqlQuery = "SELECT  ATTRFACETNAME, ATTRFACETVALUE FROM USER_ATTR_AFFINITY WHERE USERS_ID=? AND CATID=? AND ISATTRPREF=?";
		Serializable sqlParam[] = { userId, categoryId,  isattrPref};		
		
		Vector result = null;
		List<String> userCat = null;		
		ServerJDBCHelperAccessBean helperAB = new ServerJDBCHelperAccessBean();
		try {
			prefAttrMap = new HashMap<String,String>();
			result = helperAB.executeParameterizedQuery(sqlQuery, sqlParam);
			 
		} catch (RemoteException | NamingException | SQLException
				| CreateException e) {			
			LOGGER.logp(Level.SEVERE, CLASSNAME, METHODNAME,  "Exception while User's Attribute Preference", e.getMessage());			
		}		
		String temp = null, attrName = null, attrValue = null, prevattrValue = "";
		if(result != null) {
		for(Object obj : result ) {
			Vector row = (Vector) obj;
			attrName = row.get(0).toString();
			attrValue = row.get(1).toString();
			if(prefAttrMap != null && prefAttrMap.containsKey(attrName)) {				
				attrValue = prefAttrMap.get(attrName)+":"+attrValue;				
			}			
			prefAttrMap.put(attrName, attrValue);
			
        }
			setPrefAttrMap(prefAttrMap);
			if(prefAttrMap.size()>0)
			setAttrPrefCount(""+prefAttrMap.size());
			
			/*
			 *  Code to Fetch the Search Attrubute Id
			 */
			String storeId = null,attrKeyTemp = null;
			Integer storeIdInt = getCommandContext().getStoreId();
			if(storeIdInt != null) {
				storeId = String.valueOf(storeIdInt);
			}
			Map attrMap = new HashMap<String,String>();
			if(prefAttrMap!= null && prefAttrMap.size() >0) {
				for (String attrKey : prefAttrMap.keySet()) {
					/*if("BRAND".equalsIgnoreCase(attrKey)) {
						// Code to Fetch brand facet srch attr Id
						attrKeyTemp = getBrandSearchAttributeId();
						if(!StringUtils.isEmpty(attrKeyTemp)) {
							attrMap.put(attrKeyTemp, prefAttrMap.get(attrKey));
						}
					}
					else if ("PRICE".equalsIgnoreCase(attrKey)) {
						// Code to Fetch brand facet srch attr Id
						attrMap.put(attrKeyTemp, prefAttrMap.get(attrKey));
					}*/
					//else {
						attrKeyTemp = getSearchAttributeId(attrKey, storeId);
						if(StringUtils.isEmpty(attrKeyTemp)) {
							String casId = getCatalogStoreId(storeId);
							if(!StringUtils.isEmpty(casId))
							attrKeyTemp = getSearchAttributeId(attrKey, casId);	
						}
						if(!StringUtils.isEmpty(attrKeyTemp)) {
							attrMap.put("ads_f"+attrKeyTemp+"_ntk_cs", prefAttrMap.get(attrKey));
						}
						
					//}
					
				}
			}
			
			if(attrMap !=null && attrMap.size() >0) {
				setPrefAttrMap(attrMap);
				setAttrPrefCount(""+attrMap.size());
			}

		}
		
		
	
	}
	
	/**
	 * @param userId	 
	 * @return List
	 * This method will accept userId and return list of affinity attribute affinity for the user.	 
	 */

	public void getUserAffinityAttribute(String userId, String categoryId, String isattrPref){
		
		String METHODNAME = "getUserAffinityAttribute";
		if (LoggingHelper.isEntryExitTraceEnabled(LOGGER))
		LOGGER.entering(CLASSNAME, METHODNAME);		
		
		String sqlQuery = "SELECT  ATTRFACETNAME, ATTRFACETVALUE FROM USER_ATTR_AFFINITY WHERE USERS_ID=? AND CATID=? AND ISATTRPREF=?";
		Serializable sqlParam[] = { userId, categoryId,  isattrPref};		
		
		Vector result = null;
		List<String> userCat = null;		
		ServerJDBCHelperAccessBean helperAB = new ServerJDBCHelperAccessBean();
		try {
			prefAttrMap = new HashMap<String,String>();
			result = helperAB.executeParameterizedQuery(sqlQuery, sqlParam);
			 
		} catch (RemoteException | NamingException | SQLException
				| CreateException e) {			
			LOGGER.logp(Level.SEVERE, CLASSNAME, METHODNAME,  "Exception while User's Attribute Affinity", e.getMessage());			
		}		
		String temp = null, attrName = null, attrValue = null, attrFacetId = null,prevattrValue = "";
		Object tempObj = null;
		if(result != null) {
		for(Object obj : result ) {
			Vector row = (Vector) obj;
			tempObj = row.get(0);
			if(tempObj != null) {
			attrName = row.get(0).toString();
			}
			tempObj = row.get(1);
			if(tempObj != null) {
			attrValue = row.get(1).toString();
			}
			//attrFacetId = row.get(2).toString();
			if(prefAttrMap != null && prefAttrMap.containsKey(attrName)) {				
				attrValue = prefAttrMap.get(attrName)+":"+attrValue;				
			}
			if(!StringUtils.isEmpty(attrName) && attrName.startsWith("price"))
			prefAttrMap.put(attrName, attrValue);
			else
				prefAttrMap.put(attrName, attrValue);
			
        }
			setPrefAttrMap(prefAttrMap);
			if(prefAttrMap.size()>0)
			setAttrPrefCount(""+prefAttrMap.size());
			
			/*
			 *  Code to Fetch the Search Attrubute Id
			 */
			String storeId = null,attrKeyTemp = null;
			Integer storeIdInt = getCommandContext().getStoreId();
			if(storeIdInt != null) {
				storeId = String.valueOf(storeIdInt);
			}
			Map attrMap = new HashMap<String,String>();
			if(prefAttrMap!= null && prefAttrMap.size() >0) {
				for (String attrKey : prefAttrMap.keySet()) {
					/*if("BRAND".equalsIgnoreCase(attrKey)) {
						// Code to Fetch brand facet srch attr Id
						attrKeyTemp = getBrandSearchAttributeId();
						if(!StringUtils.isEmpty(attrKeyTemp)) {
							attrMap.put(attrKeyTemp, prefAttrMap.get(attrKey));
						}
					}*/
					if ("PRICE".equalsIgnoreCase(attrKey)) {
						// Code to Fetch brand facet srch attr Id
						attrMap.put(attrKey, prefAttrMap.get(attrKey));
					}
					else {
						attrKeyTemp = getSearchAttributeId(attrKey, storeId);
						if(StringUtils.isEmpty(attrKeyTemp)) {
							String casId = getCatalogStoreId(storeId);
							if(!StringUtils.isEmpty(casId))
							attrKeyTemp = getSearchAttributeId(attrKey, casId);	
						}
						if(!StringUtils.isEmpty(attrKeyTemp)) {
							attrMap.put(attrKeyTemp, prefAttrMap.get(attrKey));
						}
						
					}
					
				}
			}
			
			if(attrMap !=null && attrMap.size() >0) {
				setPrefAttrMap(attrMap);
				setAttrPrefCount(""+attrMap.size());
			}
		}
		
		
	
	}
	
	/**
	 * @param searchTerm
	 * @param pageNum
	 * @param pageSize
	 * @param searchProfile	 * 
	 * @return List
	 * This method will make a search call and fetched the list of category by search term and return this.
	 *  
	 */
	
	public List<String> getPrefferedCategoryBySearchTerm(String searchTerm, String pageNum, String pageSize, String searchProfile) {
		
		String METHODNAME = "getPrefferedCategoryBySearchTerm";
		if (LoggingHelper.isEntryExitTraceEnabled(LOGGER))
		LOGGER.entering(CLASSNAME, METHODNAME);
		
		List<String> userPrefCategory = null;
		String storeId = null;
		Integer storeIdInt = getCommandContext().getStoreId();
		if(storeIdInt != null) {
			storeId = String.valueOf(storeIdInt);
		}
		if (!StringUtils.isEmpty(searchTerm) && !StringUtils.isEmpty(storeId)) {
			
		userPrefCategory = new ArrayList<String>();
		int expectedReturnCode;
		JSONObject jsonResponse = null;
		JSONObject jsonObjfacetViewData = null;
		JSONArray facetViewData = null;
		JSONArray arrfacetViewEntryData = null;
		JSONObject arrfacetViewEntry = null;
		StringBuilder sbURL = new StringBuilder();
		Map mapQueryParameters = new HashMap();
		
		String url = null, srchTermforUrl = searchTerm;
		if(searchTerm.contains(" ")) {
			srchTermforUrl = searchTerm.replace(" ", "+");
		}
		
		mapQueryParameters.put("pageNumber", pageNum);
		mapQueryParameters.put("pagesize", pageSize);
		mapQueryParameters.put("searchTerm", searchTerm);
		mapQueryParameters.put("searchProfile", searchProfile);
		mapQueryParameters.put("langId", getCommandContext().getLanguage());

		expectedReturnCode = HttpStatus.OK.getCode();		
		SolrSearchConfigurationRegistry env_SolrSearchConfigurationRegistry = SolrSearchConfigurationRegistry.getInstance();
        String hostname = env_SolrSearchConfigurationRegistry.getSearchServerHostname();        
        String searchHostNamePath = "http://" + hostname + ":" + env_SolrSearchConfigurationRegistry.getSearchServerPort();
        String searchContextPath = env_SolrSearchConfigurationRegistry.getSearchServerContextPath();
        String serviceUrl = searchHostNamePath + searchContextPath + "/store/" + storeId+"/productview/bySearchTerm/"+srchTermforUrl;
        
		
		try {
			jsonResponse = RemoteRestCallHelper.issueRESTServiceRequest(serviceUrl, mapQueryParameters, expectedReturnCode);			
			LOGGER.logp(Level.FINEST, CLASSNAME, METHODNAME, "json response of the search call from databean is: {0}", new Object[] { jsonResponse });			
			if ((jsonResponse != null) && (!(jsonResponse.isEmpty()))) {
				if (jsonResponse.containsKey("facetView")) {
					facetViewData = jsonResponse.getJSONArray("facetView");
					if ((facetViewData != null) && (!facetViewData.isEmpty())) {
						for(int k =0; k<facetViewData.size();k++) {
						jsonObjfacetViewData = (JSONObject) facetViewData.get(k);
						if(jsonObjfacetViewData.containsKey("name") && "ParentCatalogGroup".equalsIgnoreCase(jsonObjfacetViewData.getString("name"))) {
						if (jsonObjfacetViewData.containsKey("entry")) {
							arrfacetViewEntryData = jsonObjfacetViewData.getJSONArray("entry");
							if ((arrfacetViewEntryData != null) && (!arrfacetViewEntryData.isEmpty())) {
								for(int i=0; i<arrfacetViewEntryData.length();i++) {
									arrfacetViewEntry = (JSONObject) arrfacetViewEntryData.get(i);
									userPrefCategory.add(arrfacetViewEntry.getString("value"));
								}
							}
						}
						}
					}
					}
				}
			} else {								
				LOGGER.logp(Level.INFO, CLASSNAME, METHODNAME, "There is no search result for the search term"+searchTerm);				
			}
		} 
		catch (JSONException jsone) {
			LOGGER.logp(Level.SEVERE, CLASSNAME, METHODNAME, jsone.getMessage());
		} catch (RemoteCallException re) {
			LOGGER.logp(Level.SEVERE, CLASSNAME, METHODNAME, re.getMessage());
		}
		
		}
		
		if (LoggingHelper.isEntryExitTraceEnabled(LOGGER))
			LOGGER.exiting(CLASSNAME, METHODNAME, userPrefCategory);
		
		return userPrefCategory;
	}
	
	/**
	 * @param attrName
	 * @param storeId	 
	 * @return String
	 * This method will retrun the search attributeId for each attribute Facet.	 
	 */

	public String getSearchAttributeId(String attrName, String storeId) {
		
		String METHODNAME = "getUserAffinityAttribute";
		if (LoggingHelper.isEntryExitTraceEnabled(LOGGER))
		LOGGER.entering(CLASSNAME, METHODNAME);		
		
		String sqlQuery = "SELECT FACET.SRCHATTR_ID, FACET.STOREENT_ID FROM FACET INNER JOIN ATTR ON (ATTR.ATTR_ID = FACET.ATTR_ID ) INNER JOIN ATTRDESC ON (ATTR.ATTR_ID = ATTRDESC.ATTR_ID AND LANGUAGE_ID=-1 AND NAME=? ) WHERE FACET.STOREENT_ID=?";
		Serializable sqlParam[] = {attrName, storeId};		
		
		Vector result = null;
		List<String> userCat = null;		
		ServerJDBCHelperAccessBean helperAB = new ServerJDBCHelperAccessBean();
		try {			
			result = helperAB.executeParameterizedQuery(sqlQuery, sqlParam);
			 
		} catch (RemoteException | NamingException | SQLException
				| CreateException e) {			
			LOGGER.logp(Level.SEVERE, CLASSNAME, METHODNAME,  "Exception while Fetching Search Attribute Id for attribute "+attrName, e.getMessage());			
		}		
		String temp = null, srchattrId = null, attrValue = null, attrFacetId = null,prevattrValue = "";
		Object tempObj = null;
		if(result != null) {
		for(Object obj : result ) {
			Vector row = (Vector) obj;
			tempObj = row.get(0);
			if(tempObj != null) {
				srchattrId = row.get(0).toString();
			}
      }
		}
		
	return srchattrId;	
	
	}

	/**
	 * 	 
	 * @return String
	 * This method will return the search attribute Id for Brand Facet.	 
	 */

	public String getBrandSearchAttributeId() {
		
		String METHODNAME = "getUserAffinityAttribute";
		if (LoggingHelper.isEntryExitTraceEnabled(LOGGER))
		LOGGER.entering(CLASSNAME, METHODNAME);		
		
		String sqlQuery = "SELECT SRCHATTR_ID FROM SRCHATTR WHERE IDENTIFIER=?";
		String identifier = "_cat.ManufacturerName";
		Serializable sqlParam[] = {identifier};		
		
		Vector result = null;
		List<String> userCat = null;		
		ServerJDBCHelperAccessBean helperAB = new ServerJDBCHelperAccessBean();
		try {			
			result = helperAB.executeParameterizedQuery(sqlQuery, sqlParam);
			 
		} catch (RemoteException | NamingException | SQLException
				| CreateException e) {			
			LOGGER.logp(Level.SEVERE, CLASSNAME, METHODNAME,  "Exception while Fetching Search Attribute Id for attribute ", e.getMessage());			
		}		
		String temp = null, srchattrId = null, attrValue = null, attrFacetId = null,prevattrValue = "";
		Object tempObj = null;
		if(result != null) {
		for(Object obj : result ) {
			Vector row = (Vector) obj;
			tempObj = row.get(0);
			if(tempObj != null) {
				srchattrId = row.get(0).toString();
			}
      }
		}
		
		if (LoggingHelper.isEntryExitTraceEnabled(LOGGER))
			LOGGER.exiting(CLASSNAME, METHODNAME, srchattrId);
		
	return srchattrId;	
	
	}
	
	/**
	 * @param userId
	 * @param categoryId	 
	 * @return void
	 * This method will accept userId and categoryId and update the affinity attribute map with brand details for the user.	 
	 */

	public void getUserBrandAffinityAttribute(String userId, String categoryId){
		
		String METHODNAME = "getUserBrandAffinityAttribute";
		if (LoggingHelper.isEntryExitTraceEnabled(LOGGER))
		LOGGER.entering(CLASSNAME, METHODNAME);		
		
		String sqlQuery = "SELECT  BRAND FROM USER_CAT_AFFINITY WHERE USERS_ID=? AND CATID=?";
		Serializable sqlParam[] = {userId, categoryId};		
		
		Vector result = null;
		List<String> userCat = null;		
		ServerJDBCHelperAccessBean helperAB = new ServerJDBCHelperAccessBean();
		try {
			//prefAttrMap = new HashMap<String,String>();
			result = helperAB.executeParameterizedQuery(sqlQuery, sqlParam);
			 
		} catch (RemoteException | NamingException | SQLException
				| CreateException e) {			
			LOGGER.logp(Level.SEVERE, CLASSNAME, METHODNAME,  "Exception while User's Attribute Affinity", e.getMessage());			
		}		
		String brandSrchAttrId = null, attrValue = null;
		Object tempObj = null;
		if(result != null) {
		for(Object obj : result ) {
			Vector row = (Vector) obj;
			tempObj = row.get(0);
			if(tempObj != null) {
				attrValue = row.get(0).toString();
			}
			
			}
			//attrFacetId = row.get(2).toString();
			if(prefAttrMap != null) {
				brandSrchAttrId = getBrandSearchAttributeId();
				if(!StringUtils.isEmpty(brandSrchAttrId))
				prefAttrMap.put(brandSrchAttrId, attrValue);			
			}
	}
		
		if (LoggingHelper.isEntryExitTraceEnabled(LOGGER))
			LOGGER.exiting(CLASSNAME, METHODNAME, attrValue);
	
	}
	
	/**
	 * @param storeId	 
	 * @return String
	 * This method will accept storeId and return the related catalog storeId.	 
	 */

	public String getCatalogStoreId(String storeId) {
		
		String METHODNAME = "getUserBrandAffinityAttribute";
		if (LoggingHelper.isEntryExitTraceEnabled(LOGGER))
		LOGGER.entering(CLASSNAME, METHODNAME);		
		
		String sqlQuery = "SELECT RELATEDSTORE_ID FROM STOREREL WHERE STRELTYP_ID=-4 and store_id=? and RELATEDSTORE_ID<>?";
		Serializable sqlParam[] = {storeId,storeId};		
		
		Vector result = null;
		List<String> userCat = null;
		String casId= null;
		ServerJDBCHelperAccessBean helperAB = new ServerJDBCHelperAccessBean();
		try {
			//prefAttrMap = new HashMap<String,String>();
			result = helperAB.executeParameterizedQuery(sqlQuery, sqlParam);
			 
		} catch (RemoteException | NamingException | SQLException
				| CreateException e) {			
			LOGGER.logp(Level.SEVERE, CLASSNAME, METHODNAME,  "Exception while User's Attribute Affinity", e.getMessage());			
		}		
		String temp = null, attrValue = null ;
		Object tempObj = null;
		if(result != null) {
		for(Object obj : result ) {
			Vector row = (Vector) obj;
			tempObj = row.get(0);
			if(tempObj != null) {
				attrValue = row.get(0).toString();
			}			
			}
			
	}
		
		if (LoggingHelper.isEntryExitTraceEnabled(LOGGER))
			LOGGER.exiting(CLASSNAME, METHODNAME, attrValue);
		
		return attrValue;
	
	}



}
