package com.ext.commerce.user.commands;

import java.rmi.RemoteException;
import java.util.Enumeration;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.naming.NamingException;

import org.apache.commons.lang3.StringUtils;

import scala.collection.Map;
import scala.collection.mutable.HashMap;

import com.ibm.commerce.beans.SmartDataBean;
import com.ibm.commerce.beans.SmartDataBeanImpl;
import com.ibm.commerce.foundation.common.util.logging.LoggingHelper;
import com.ibm.commerce.user.objects.MemberAttributeAccessBean;
import com.ibm.commerce.user.objects.MemberAttributeStringValueAccessBean;

/**
 * @author IBM
 * This data bean fetches the user user synonym dictionary based on the supplied search term. 	 
 * 
 */

public class GetSynonymDictionaryBySearchTermDB extends SmartDataBeanImpl implements
		SmartDataBean {
	private static final String CLASSNAME = "com.ext.commerce.user.commands.GetSynonymDictionaryBySearchTermDB";
	private static final Logger LOGGER = LoggingHelper.getLogger(CLASSNAME);
	
	private String replacedTerm = null;
	private String searchTerm = null;
	
	public String getReplacedTerm() {
		return replacedTerm;
	}

	public void setReplacedTerm(String replacedTerm) {
		this.replacedTerm = replacedTerm;
	}
	
	public String getSearchTerm() {
		return searchTerm;
	}
	public void setSearchTerm(String searchTerm) {
		this.searchTerm = searchTerm;
	}

	/**
	 * @param userId	 
	 * @return List
	 * @throws Exception
	 * The main populate method will accept the search term and find the user dictionary string matching with the search term.
	 * 
	 */
	
	@Override
	public void populate() throws Exception {
		// TODO Auto-generated method stub
		String METHODNAME = "populate";
		if (LoggingHelper.isEntryExitTraceEnabled(LOGGER))
		LOGGER.entering(CLASSNAME, METHODNAME);
		
		super.populate();	
		Long userId = getCommandContext().getUserId();
		String userIdStr = "", userTerm= "";
		if(userId != null) {
		 userIdStr = String.valueOf(userId);
		 String attributeId = getMemberAttributeByName(userIdStr, "SynonymDictionary");
		 userTerm = getUserDictionarybyTerm(userIdStr, attributeId);
		 setReplacedTerm(userTerm);
		}
		
		if (LoggingHelper.isEntryExitTraceEnabled(LOGGER))
			LOGGER.exiting(CLASSNAME, METHODNAME, userTerm);
		
	}
	

	/**
	 * @param userId	 
	 * @param attrName	
	 * @return String
	 * This method will return UserSynonymDictionary attribute Id.
	 *  
	 */
	
	private String getMemberAttributeByName(String userId, String attrName)

	{
		String METHODNAME = "getMemberAttributeByName";
		if (LoggingHelper.isEntryExitTraceEnabled(LOGGER))
		LOGGER.entering(CLASSNAME, METHODNAME);
		
	    	
	    	Enumeration mbrAttrEnum = null;
	    	String mbrattrId = "";
	    	MemberAttributeAccessBean mbrAtttrBean = new MemberAttributeAccessBean();
	    	try {
	    		mbrAttrEnum= mbrAtttrBean.findByAttributeName(attrName);
	    		while (mbrAttrEnum.hasMoreElements()) {	    			
	    			MemberAttributeAccessBean mbrattr = (MemberAttributeAccessBean)mbrAttrEnum.nextElement();
	    			mbrattrId = String.valueOf(mbrattr.getMemberAttributeIdInEJBType());
	    		}
	    		
	    		
			} catch (RemoteException|FinderException|NamingException|CreateException e1) {
				
				LOGGER.logp(Level.SEVERE, CLASSNAME, METHODNAME, "Exception while fetching SynonymDictionary Attribute ID", e1.getMessage());
			}
	    	
	    	if (LoggingHelper.isEntryExitTraceEnabled(LOGGER))
				LOGGER.exiting(CLASSNAME, METHODNAME, mbrattrId);
	    	
	    	
	    	return mbrattrId;
	}
	
	
	/**
	 * @param userId
	 * @param attrId	
	 * @return String
	 * This method will return UserSynonymDictionary attribute Value.
	 *  
	 */
	
	private String getUserDictionarybyTerm(String userId, String attrId)

	{
		String METHODNAME = "getUserDictionarybyTerm";
		if (LoggingHelper.isEntryExitTraceEnabled(LOGGER))
		LOGGER.entering(CLASSNAME, METHODNAME);	
		
	    	
	    	Enumeration MemberAttrValEnum = null;
	    	Map<String,String> userDictionary = new HashMap<String,String>();
	    	
	    	
	    	MemberAttributeStringValueAccessBean mbrAttrValBean = new MemberAttributeStringValueAccessBean();
	    	String termKey= null,termValue=null, userTerm="", dictWord="";
	    	try {
	    		MemberAttrValEnum = mbrAttrValBean.findByMemberIdAndAttributeId(Long.parseLong(userId), Long.parseLong(attrId));
	    		while (MemberAttrValEnum.hasMoreElements()) {
	    			MemberAttributeStringValueAccessBean pCodeattrValue = (MemberAttributeStringValueAccessBean)MemberAttrValEnum.nextElement();
	    			dictWord = (String)pCodeattrValue.getAttributeValue();
	    			if(!StringUtils.isEmpty(dictWord) && dictWord.contains("=")) {
	    				termKey = StringUtils.substringBefore(dictWord, "=");
	    				termValue = StringUtils.substringAfter(dictWord, "=");
	    				if(!StringUtils.isEmpty(termKey)) {
	    					termKey = termKey.trim();
	    					if(termKey.equalsIgnoreCase(getSearchTerm())) {
	    						userTerm = termValue;
	    						if(!StringUtils.isEmpty(userTerm)) {
	    							userTerm = userTerm.trim();
	    						break;
	    						}
	    					}
	    					
	    				}
	    				
	    			}
				
	    		}
			} catch (NumberFormatException |RemoteException|FinderException|NamingException e) {
				// TODO Auto-generated catch block
				LOGGER.logp(Level.SEVERE, CLASSNAME, METHODNAME, "Exception while fetching UserDictionary Term from supplied Search Term", e.getMessage());
			}
	    	
	    	if (LoggingHelper.isEntryExitTraceEnabled(LOGGER))
				LOGGER.exiting(CLASSNAME, METHODNAME, userTerm);
	    	
	    	return userTerm;
	}

	

}
