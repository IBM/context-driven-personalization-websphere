package com.ext.commerce.catalog.commands;


import java.rmi.RemoteException;
import java.util.Map;
import java.util.logging.Logger;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.naming.NamingException;

import org.apache.commons.lang3.StringUtils;

import com.ext.commerce.user.commands.GetUserAffinityDataBean;
import com.ibm.commerce.beans.DataBeanManager;
import com.ibm.commerce.catalog.commands.SearchDisplayCmdImpl;
import com.ibm.commerce.command.CommandContext;
import com.ibm.commerce.datatype.TypedProperty;
import com.ibm.commerce.exception.ECException;
import com.ibm.commerce.foundation.common.util.logging.LoggingHelper;
import com.ibm.commerce.foundation.internal.server.services.search.util.SpecialCharacterHelper;
import com.ibm.commerce.user.objects.UserAccessBean;


	/**
	 * @author IBM
	 * This command check if user is registered and category is empty. User affinity towards category and attribute is fetched and returned to search display view. 	 
	 * 
	 */

public class ExtSearchDisplayCmdImpl extends SearchDisplayCmdImpl
  
{
  public static final String COPYRIGHT = "(c) Copyright International Business Machines Corporation 1996,2008";
  private static final String CLASSNAME = ExtSearchDisplayCmdImpl.class.getName();
  private static final Logger LOGGER = LoggingHelper.getLogger(CLASSNAME);



  	/**
	 * 	 
	 * @return void
	 * @throws ECExcpetion
	 * This method will redirect to the search display view if user is registered and have some attribute affinity.	 
	 */


  public void performExecute() throws ECException {
	  
	  String METHODNAME = "performExecute";
	  if (LoggingHelper.isEntryExitTraceEnabled(LOGGER))
		LOGGER.entering(CLASSNAME, METHODNAME);
	  CommandContext cmdCtxt = getCommandContext();
	  TypedProperty reqProp = getRequestProperties();
	  String userPrefSearch = "";
	  UserAccessBean userAB = getCommandContext().getUser();
	  Boolean catexist = true;
	  String userType = null;
	  String categoryId = null;
	  String srchTerm = null;
	  try {
		 userType = userAB.getRegisterType();
	 } catch (RemoteException | CreateException | FinderException
			| NamingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	   
	  try {
	   categoryId =  reqProp.getString("categoryId");
	   userPrefSearch = reqProp.getString("userPrefSearch");
	   srchTerm = reqProp.getString("searchTerm");
	  }
	  catch(Exception ex) {
		  categoryId = "";
		  userPrefSearch = "false";
		  srchTerm = "";
	  }
	  
	  if(!StringUtils.isEmpty(srchTerm) && StringUtils.isEmpty(categoryId) && !StringUtils.isEmpty(userType) && "R".equalsIgnoreCase(userType) && "true".equalsIgnoreCase(userPrefSearch)) {      
	  GetUserAffinityDataBean usrAffinityDB = new GetUserAffinityDataBean();
	  usrAffinityDB.setSearchTerm(srchTerm);
	  DataBeanManager.activate(usrAffinityDB, cmdCtxt);
	  reqProp.put("categoryId", usrAffinityDB.getCategoryId());
	  reqProp.put("categoryFacetHierarchyPath", usrAffinityDB.getCategoryId());
	  reqProp.put("pageView", "grid");
	  reqProp.put("filterTerm", "");
	  reqProp.put("metaData", "");
	  reqProp.put("urlLangId", "-1");
	  reqProp.put("advancedSearch", "");
	  reqProp.put("showResultsPage", "true");
	  
	  if(!StringUtils.isEmpty(usrAffinityDB.getCategoryId())) {       
	  
	  GetUserAffinityDataBean usrAttrDB = new GetUserAffinityDataBean();
	  usrAttrDB.setCategoryId(usrAffinityDB.getCategoryId());
	  usrAttrDB.setIsAttinity("true");
	  DataBeanManager.activate(usrAttrDB, cmdCtxt);
	  
	  String attrName = null, attrValueStr = null, attrValue = null, facetStr="",attrFacetId="";
	  String facetId = "", finalfacetStr="";
	  String [] tempArray = null;
	  Map<String,String> attrMap =  usrAttrDB.getPrefAttrMap();
	  if(attrMap !=null && attrMap.size() >0) {
		  for (Map.Entry<String, String> entry : attrMap.entrySet())
		  {
			  attrName = entry.getKey() ;
			  attrValueStr = entry.getValue();
			  
			  if(!StringUtils.isEmpty(attrName) && !StringUtils.isEmpty(attrValueStr)) {
			  tempArray = attrValueStr.split(":");
			  for (int j=0; j< tempArray.length; j++) {
				  if(attrName.startsWith("price")) {
					  attrName = "price_USD";
					  tempArray[j] = getPricFacetValue(attrValueStr);
					  facetStr = attrName+":"+ tempArray[j];
					  facetId = SpecialCharacterHelper.convertStrToAscii(facetStr);
				  }
				  else {
				  attrFacetId = attrName;
				  facetStr = tempArray[j];
				  facetId = SpecialCharacterHelper.convertStrToAscii(facetStr);
				  facetId = attrFacetId+facetId;				  
				  }				 
			      finalfacetStr = finalfacetStr+ ","+facetId;
			      
			  }
		  }
			  if(!StringUtils.isEmpty(finalfacetStr)) {
				 if(finalfacetStr.startsWith(",")) {
					 finalfacetStr =StringUtils.substringAfter(finalfacetStr, ",");
					 
				 }
				  
			  }
		  }
		  reqProp.put("userAffinity", finalfacetStr);
		  reqProp.put("userPrefSearch","true");
	  } }
	  
	  else {
		  reqProp.put("userPrefSearch","false");
	  }
	  
	
	  super.performExecute();
	  
	 this.responseProperties.put("viewTaskName", 
	            "RedirectView");
	          this.responseProperties.put("redirecturl", 
	        		  "SearchDisplayView");	  
	  }
	  else {
		  super.performExecute();
	  }
	  
	  if (LoggingHelper.isEntryExitTraceEnabled(LOGGER))
			LOGGER.exiting(CLASSNAME, METHODNAME);
  }
  
  /**
	 * @param facetValue	 
	 * @return String
	 * This method will accept the price facet value and return the corresponding result expression which is helpful in forming Price Facet Id.	 
	 */
  
  private String getPricFacetValue(String facetValue) {
	  String METHODNAME = "getPricFacetValue";
	  if (LoggingHelper.isEntryExitTraceEnabled(LOGGER))
		LOGGER.entering(CLASSNAME, METHODNAME);
	  
	  String valuetemplate = null, lbound =null, ubound = null;
	  if(StringUtils.isNotEmpty(facetValue) && facetValue.contains("Less than")) {
		  valuetemplate ="({* PH} PH)";
		  facetValue = StringUtils.substringAfter(facetValue, "Less than");
		  facetValue = facetValue.trim();
		  facetValue = valuetemplate.replace("PH", facetValue);
		  
	  }
	  else if(StringUtils.isNotEmpty(facetValue) && facetValue.contains("More than")) {
		  valuetemplate ="({PH *})";
		  facetValue = StringUtils.substringAfter(facetValue, "More than");
		  facetValue = facetValue.trim();
		  facetValue = valuetemplate.replace("PH", facetValue);
		  
	  }
	  else if(StringUtils.isNotEmpty(facetValue) && facetValue.contains("Between")) {
		  valuetemplate ="({LB UB} UB)";
		  lbound = StringUtils.substring(facetValue, 7, 11);
		  ubound = StringUtils.substringAfter(facetValue, "and");
		  if(StringUtils.isNotEmpty(lbound)&&StringUtils.isNotEmpty(ubound)) {
			  lbound = lbound.trim();
			  ubound = ubound.trim();
			  
		  }
		  facetValue = valuetemplate.replace("LB", lbound);
		  facetValue = facetValue.replace("UB", ubound);
		  
	  } 
	  
	  if (LoggingHelper.isEntryExitTraceEnabled(LOGGER))
			LOGGER.exiting(CLASSNAME, METHODNAME,facetValue);
	  
	     return facetValue;
  }




  
}

