package com.ext.commerce.foundation.server.services.rest.search.expression.solr;


import java.util.logging.Logger;

import org.apache.commons.lang.StringUtils;

import com.ibm.commerce.foundation.common.util.logging.LoggingHelper;
import com.ibm.commerce.foundation.server.services.dataaccess.SelectionCriteria;
import com.ibm.commerce.foundation.server.services.search.expression.SearchExpressionProvider;
import com.ibm.commerce.foundation.server.services.search.expression.solr.AbstractSolrSearchExpressionProvider;


/**
 * @author:IBM
 * This Expression provider will boost the search result as per the user attribute preference.  
 *
 */

public class ExtSearchBoostExpressionProvider extends AbstractSolrSearchExpressionProvider implements
SearchExpressionProvider {

	private static final String COPYRIGHT = "(c) Copyright International Business Machines Corporation 1996,2008";
	private static final String CLASSNAME = ExtSearchBoostExpressionProvider.class.getName();
	
	private static final Logger LOGGER = LoggingHelper.getLogger(ExtSearchBoostExpressionProvider.class);
	private String iComponentId = null;	
	
	public ExtSearchBoostExpressionProvider(String componentId) {
		this.iComponentId = componentId;
		
	}
	

	/**
	 * @Method The Method will read the attribute user preffered attribute and boost the search result based on the user attribute preference.	 * 
	 * @param selectionCriteria
	 * @return void
	 */

	public void invoke(SelectionCriteria selectionCriteria) throws RuntimeException {

		String METHODNAME = "invoke";
		if (LoggingHelper.isEntryExitTraceEnabled(LOGGER)) {
			LOGGER.entering(CLASSNAME, METHODNAME);
		}

		super.invoke(selectionCriteria);
		String attrPref = "attrPref_";
		String expression = null, attrNameValueParam ="" , tempExpression="";
		String innerexpression = null;
		String [] attrNameValue = null;
		String [] tempArray = null;
		String  attrPrefCount = getControlParameterValue("attrPrefCount");
		if(!StringUtils.isEmpty(attrPrefCount)) {
		Integer count = Integer.parseInt(attrPrefCount);
		for (int i =0; i<count;i++) {
		  attrNameValueParam = getControlParameterValue(attrPref+i);
		  attrNameValue = attrNameValueParam.split("#");
		  expression = attrNameValue[0];
		  if(!StringUtils.isEmpty(attrNameValue[1])) {
			  tempArray = attrNameValue[1].split(":");
			  for (int j=0; j< tempArray.length; j++) {
				  innerexpression = expression +" : "+tempArray[j];
				  tempExpression = tempExpression + " " +innerexpression;				   
			  }
			  
		  }
		}
		
		if(!StringUtils.isEmpty(tempExpression)) {
			addControlParameterValue(
					"_wcf.search.internal.boostquery", 
					tempExpression);
			
		}
		
		System.err.println("MY CUSTOM PROVIDER EXECUTED 124\n");
		 
		/*addControlParameterValue(
				"_wcf.search.internal.boostquery", 
				"ads_f10502_ntk_cs:Purple");
		
		addControlParameterValue(
				"_wcf.search.internal.boostquery", 
				"ads_f10502_ntk_cs:Purple^500 OR ads_f10501_ntk_cs:Synthetic^1000");*/
		}
		
		if (LoggingHelper.isEntryExitTraceEnabled(LOGGER)) {
			LOGGER.exiting(CLASSNAME, METHODNAME,tempExpression);
		}


	}

	}
